import os
import tensorflow as tf
import nsml

w1 = tf.Variable(tf.random_normal(shape=[7]), name='w1')
w2 = tf.Variable(tf.random_normal(shape=[7]), name='w2')
saver = tf.train.Saver()
sess = tf.Session()
sess.run(tf.global_variables_initializer())

# NSML save
save_path = 'test_model'
model_name = 'nsml_tf_model'
load_path = 'nsml_model'
session_name = 'session_name'

os.makedirs(save_path)
saver.save(sess, save_path+'/tensor_model')
nsml.save_folder(checkpoint=model_name, checkpoint_path=save_path, metadata={'model_type': 'tensorflow'},
                 delete=True, error_raise=True)

nsml.load_folder(checkpoint=model_name, target_path=load_path, session=session_name)
