
import argparse
import os

import numpy as np
import keras
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras import backend as K
import tensorflow as tf

from mnist_reader import read_image_file, read_label_file
import nsml
from nsml import DATASET_PATH, HAS_DATASET, GPU_NUM


"""def bind_model(model):
    def load(filename):
        print('load model')
        model.load_weights(filename)

    def save(filename):
        model.save_weights(filename)

    def infer(input, top_k=100):
        input = preprocess(input)
        result = model.predict(np.expand_dims(input['data'], axis=-1))
        all_cls = result.shape[1]
        softmax_res = tf.nn.top_k(K.softmax(result), k=min(top_k, all_cls))
        prediction = tf.Session().run(softmax_res)
        return list(zip(list(prediction[0].flatten()), list(prediction[1].flatten())))

    nsml.bind(save=save, load=load, infer=infer)
"""


def infer(input, top_k=100):
    input = preprocess(input)
    result = model.predict(np.expand_dims(input, axis=-1))
    all_cls = result.shape[1]
    softmax_res = tf.nn.top_k(K.softmax(result), k=min(top_k, all_cls))
    prediction = tf.Session().run(softmax_res)
    return list(zip(list(prediction[0].flatten()), list(prediction[1].flatten())))


def preprocess(input):
    if 'PIL' in str(type(input[0])):
        for idx in range(len(input)):
            input[idx] = np.asarray(input[idx])
    return input


# supported by dataset owner
def data_loader(root_path):
    root_path = os.path.join(root_path, 'train')
    data_dict = {
        'train': {
            'data': read_image_file(os.path.join(root_path, 'train', 'train-images-idx3-ubyte')),
            'label': read_label_file(os.path.join(root_path, 'train', 'train-labels-idx1-ubyte'))
        },
        'test': {
            'data': read_image_file(os.path.join(root_path, 'test', 't10k-images-idx3-ubyte')),
            'label': read_label_file(os.path.join(root_path, 'test', 't10k-labels-idx1-ubyte'))
        }
    }
    return data_dict


if __name__ == '__main__':
    # mode argument
    args = argparse.ArgumentParser()
    args.add_argument("--mode", type=str, default="train")
    args.add_argument("--batch", type=int, default=100)
    args.add_argument("--lr", type=float, default=0.02)
    args.add_argument("--epochs", type=int, default=10)
    args.add_argument("--top", type=int, default=100)
    args.add_argument("--iteration", type=str, default="0")
    args.add_argument("--pause", type=int, default=0)
    config = args.parse_args()
    config.gpu = int(GPU_NUM)

    batch_size = config.batch
    epochs = config.epochs

    # input image dimensions
    num_classes = 10
    img_rows, img_cols = 28, 28
    if K.image_data_format() == 'channels_first':
        input_shape = (1, img_rows, img_cols)
    else:
        input_shape = (img_rows, img_cols, 1)

    model = Sequential()
    model.add(Conv2D(32, kernel_size=(3, 3),
                     activation='relu',
                     input_shape=input_shape))
    model.add(Conv2D(64, (3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.25))
    model.add(Flatten())
    model.add(Dense(128, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(num_classes, activation='softmax'))

    # for multi gpu
    if config.gpu >= 2:
        from keras.utils import multi_gpu_model
        model = multi_gpu_model(model, gpus=config.gpu)

    model.compile(loss=keras.losses.categorical_crossentropy,
                  optimizer=keras.optimizers.Adadelta(lr=config.lr),
                  metrics=['accuracy'])

    # bind_model(model)
    nsml.bind(infer=infer, model=model)

    if config.pause:
        nsml.paused(scope=locals())

    if config.mode == 'train':
        # the data, shuffled and split between train and test sets
        if HAS_DATASET:
            data = data_loader(DATASET_PATH)
            x_train = data['train']['data']
            y_train = data['train']['label']
            x_test = data['test']['data']
            y_test = data['test']['label']
        else:
            (x_train, y_train), (x_test, y_test) = mnist.load_data()
        if K.image_data_format() == 'channels_first':
            x_train = x_train.reshape(x_train.shape[0], 1, img_rows, img_cols)
            x_test = x_test.reshape(x_test.shape[0], 1, img_rows, img_cols)
        else:
            x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
            x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)

        x_train = x_train.astype('float32')
        x_test = x_test.astype('float32')
        x_train /= 255
        x_test /= 255
        print('x_train shape:', x_train.shape)
        print(x_train.shape[0], 'train samples')
        print(x_test.shape[0], 'test samples')

        # convert class vectors to binary class matrices
        y_train = keras.utils.to_categorical(y_train, num_classes).squeeze()
        y_test = keras.utils.to_categorical(y_test, num_classes).squeeze()
        for epoch in range(epochs):
            res = model.fit(x_train, y_train, batch_size=batch_size,
                            initial_epoch=epoch, epochs=epoch+1,
                            verbose=1, validation_data=(x_test, y_test))
            loss, acc, val_loss, val_acc = res.history['loss'][0], res.history['acc'][0], \
                    res.history['val_loss'][0], res.history['val_acc'][0]

            nsml.report(summary=True, step=epoch, epoch=epoch, epoch_total=epochs,
                        loss=loss, acc=acc, val_loss=val_loss, val_acc=val_acc)
            nsml.save(epoch)
        score = model.evaluate(x_test, y_test, verbose=0)
        print('Test loss:', score[0])
        print('Test accuracy:', score[1])
