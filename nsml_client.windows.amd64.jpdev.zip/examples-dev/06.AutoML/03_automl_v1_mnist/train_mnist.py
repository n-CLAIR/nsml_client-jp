#nsml: nvcr.io/nvidia/pytorch:19.09-py3

import os
from argparse import ArgumentParser
from time import sleep

import torch
import torchvision
from torch.utils.data import DataLoader
from torchvision.datasets import MNIST
from torchvision import transforms

import nsml


class Flatten(torch.nn.Module):
    def __init__(self):
        super(Flatten, self).__init__()

    def forward(self, x):
        return x.flatten(1)


transform = transforms.Compose([
    transforms.ToTensor()
])


def accuracy(output, target, topk=(1,)):
    maxk = max(topk)
    batch_size = target.size(0)

    _, pred = output.topk(maxk, 1, True, True)
    pred = pred.t()
    correct = pred.eq(target.view(1, -1).expand_as(pred))

    res = []
    for k in topk:
        correct_k = correct[:k].view(-1).float().sum(0)
        res.append(correct_k.mul_(100.0 / batch_size))
    return res[0] if len(topk) == 1 else res


def train_for_one_epoch(**kwargs):
    global global_step
    model        = kwargs['model']
    criterion    = kwargs['criterion']
    optimizer    = kwargs['optimizer']
    train_loader = kwargs['train_loader']

    for i, (X, y) in enumerate(train_loader):
        # Prepare data
        X = X.to(device)
        y = y.to(device, non_blocking=True)

        # Forward
        logits = model(X)
        prec1 = accuracy(logits, y)
        if i % 100 == 0:
            print('Precision:', prec1.item())
        loss = criterion(logits, y)
        nsml.report(scope=locals(), summary=True, step=global_step, acc=prec1.item())

        # Backward
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        global_step += 1
    return


def test_for_one_epoch(**kwargs):
    global global_step
    model       = kwargs['model']
    criterion   = kwargs['criterion']
    test_loader = kwargs['test_loader']

    prec1 = 0
    cnt = 0
    for X, y in test_loader:
        # Prepare data
        X = X.to(device)
        y = y.to(device, non_blocking=True)

        # Forward
        logits = model(X)
        loss = criterion(logits, y)
        prec1 += accuracy(logits, y)
        cnt += 1

    nsml.report(scope=locals(), summary=True, step=global_step, test__acc=prec1.item()/cnt)

def bind_model(model):
    def save(dir_path):
        global global_step
        state = {
            'model': model.state_dict(),
            'step' : global_step
        }
        torch.save(state, os.path.join(dir_path, 'model.pt'))

    def load(dir_path):
        global global_step
        state = torch.load(os.path.join(dir_path, 'model.pt'))
        model.load_state_dict(state['model'])
        global_step = state['step']
        print(state['step'])
        if 'optimizer' in state and optimizer:
            optimizer.load_state_dict(state['optimizer'])
            print('optimizer loaded!')
        print('model loaded!')

    def infer(input_data, top_k):
        model.eval()
        # from list to tensor
        image = torch.stack(preprocess(None, input_data))
        image = Variable(image.cuda())
        clean_state, _ = model(image)
        batch_size, all_cls = clean_state.size()
        # prediction format: ([torch.Tensor], [toch.Tensor)
        prediction = F.softmax(clean_state).topk(min(top_k, all_cls))
        # output format
        # [[(key, prob), (key, prob)... ], ...]
        return list(zip(list(prediction[0].data.cpu().squeeze().tolist()),
                        list(prediction[1].data.cpu().squeeze().tolist())))

    nsml.bind(save=save, load=load, infer=infer)

if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--epochs', type=int, default=4, help='Number of epochs to train')
    parser.add_argument('--lr', type=float, default=0.001, help='Learning rate value')
    parser.add_argument('--l2', type=float, default=0.0001, help='l2 regularization factor')
    parser.add_argument('--hidden', type=int, default=32, help='Hidden')
    parser.add_argument('--batch-size', type=int, default=512, help='Size of the batch to use')
    parser.add_argument('--mode', type=str, help='For NSML fork')
    parser.add_argument('--pause', type=int, help='For NSML fork')
    parser.add_argument('--iteration', type=int, help='For NSML fork')
    args = parser.parse_args()

    torch.manual_seed(1)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # Define dataset and dataloader
    data_path = os.path.join(nsml.DATASET_PATH, 'train')
    train_set = MNIST(data_path, train=True, transform=transform, download=False)
    test_set = MNIST(data_path, train=False, transform=transform, download=False)

    train_loader = DataLoader(
        train_set, batch_size=args.batch_size, pin_memory=True, num_workers=1
    )
    test_loader = DataLoader(
        test_set, batch_size=args.batch_size, shuffle=False, pin_memory=True, num_workers=1
    )

    # Define model
    model = torch.nn.Sequential(
        Flatten(),
        torch.nn.Linear(28*28, args.hidden),
        torch.nn.ReLU(),
        torch.nn.Linear(args.hidden, 10)
    )
    model = model.to(device)

    # Define optimizer
    optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, weight_decay=args.l2)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, float(args.epochs))

    # Define criterion
    criterion = torch.nn.CrossEntropyLoss()

    # Initialize global_step to 0
    global_step = 0
    bind_model(model)
    if args.pause:
        nsml.paused(locals())
    test_kwargs = {
        'model': model,
        'criterion': criterion,
        'test_loader': test_loader,
    }
    test_for_one_epoch(**test_kwargs)
    for i in range(args.epochs):
        print('epoch', i)
        train_kwargs = {
            'model': model,
            'criterion': criterion,
            'optimizer': optimizer,
            'train_loader': train_loader
        }
        train_for_one_epoch(**train_kwargs)

        test_kwargs = {
            'model': model,
            'criterion': criterion,
            'test_loader': test_loader,
        }
        test_for_one_epoch(**test_kwargs)
        scheduler.step()
        nsml.save(i)
