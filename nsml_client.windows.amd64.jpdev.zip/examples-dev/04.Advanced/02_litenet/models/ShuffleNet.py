import torch
import torch.nn as nn
import torchvision.models as models
import torch.utils.model_zoo as model_zoo
import torch.nn.functional as F
torch.backends.cudnn.benchmark = True
torch.backends.cudnn.fastest = True

class ShuffleBlock(nn.Module):
  def __init__(self, groups):
    super(ShuffleBlock, self).__init__()
    self.groups = groups

  def forward(self, x):
    '''Channel shuffle: [N,C,H,W] -> [N,g,C/g,H,W] -> [N,C/g,g,H,w] -> [N,C,H,W]'''
    N,C,H,W = x.size()
    g = self.groups
    return x.view(N,g,int(C/g),H,W).permute(0,2,1,3,4).contiguous().view(N,C,H,W)

class Bottleneck(nn.Module):
  def __init__(self, in_planes, out_planes, stride, groups):
    super(Bottleneck, self).__init__()
    self.stride = stride

    assert out_planes % 4 == 0

    mid_planes = int(out_planes/4)
    g = 1 if in_planes==24 else groups
    self.conv1 = nn.Conv2d(in_planes, mid_planes, kernel_size=1, groups=g, bias=False)
    self.bn1 = nn.BatchNorm2d(mid_planes)
    self.shuffle1 = ShuffleBlock(groups=g)
    self.conv2 = nn.Conv2d(mid_planes, mid_planes, kernel_size=3, stride=stride, padding=1, groups=mid_planes, bias=False)
    self.bn2 = nn.BatchNorm2d(mid_planes)
    self.conv3 = nn.Conv2d(mid_planes, out_planes, kernel_size=1, groups=groups, bias=False)
    self.bn3 = nn.BatchNorm2d(out_planes)

    self.shortcut = nn.Sequential()
    if stride == 2:
      self.shortcut = nn.Sequential(nn.AvgPool2d(3, stride=2, padding=1))

  def forward(self, x):
    out = F.relu(self.bn1(self.conv1(x)))
    out = self.shuffle1(out)
    out = F.relu(self.bn2(self.conv2(out)))
    out = self.bn3(self.conv3(out))
    res = self.shortcut(x)
    out = F.relu(torch.cat([out,res], 1)) if self.stride==2 else F.relu(out+res)
    return out


class Net(nn.Module):
  def __init__(self, cfg):
    super(Net, self).__init__()
    out_planes = cfg['out_planes']
    num_blocks = cfg['num_blocks']
    groups = cfg['groups']

    in_c = cfg['in_c']
    num_classes = cfg['num_classes']
    self.ngpu = cfg['ngpu']
    image_size = cfg['image_size']

    if image_size == 32:
      self.conv1 = nn.Conv2d(in_c, 24, kernel_size=1, bias=False)
    elif image_size == 224:
      self.conv1 = nn.Conv2d(in_c, 24, kernel_size=3, stride=2, padding=1, bias=False)
      self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
    self.bn1 = nn.BatchNorm2d(24)
    self.relu1 = nn.ReLU(inplace=True)

    self.in_planes = 24
    self.layer1 = self._make_layer(out_planes[0], num_blocks[0], groups)
    self.layer2 = self._make_layer(out_planes[1], num_blocks[1], groups)
    self.layer3 = self._make_layer(out_planes[2], num_blocks[2], groups)
    self.fc = nn.Linear(out_planes[2], num_classes)

    if image_size == 32:
      self.model = nn.Sequential(self.conv1, self.bn1, self.relu1, self.layer1, self.layer2, self.layer3)
    elif image_size == 224:
      self.model = nn.Sequential(self.conv1, self.bn1, self.relu1, self.maxpool1, self.layer1, self.layer2, self.layer3)

  def _make_layer(self, out_planes, num_blocks, groups):
    layers = []
    for i in range(num_blocks):
      stride = 2 if i == 0 else 1
      cat_planes = self.in_planes if i == 0 else 0
      layers.append(Bottleneck(self.in_planes, out_planes-cat_planes, stride=stride, groups=groups))
      self.in_planes = out_planes
    return nn.Sequential(*layers)

  def forward(self, x):
    if isinstance(x.data, torch.cuda.FloatTensor) and self.ngpu > 1:
      x = nn.parallel.data_parallel(self.model, x, range(self.ngpu))
    else: 
      x = self.model(x)
    x = F.avg_pool2d(x, kernel_size=x.size()[2:])
    x = x.view(x.size(0), -1)
    x = self.fc(x)
    return x


def ShuffleNetG2(in_c=3, image_size=224, num_classes=10, ngpu=1):
  cfg = {
    'out_planes': [200,400,800],
    'num_blocks': [4,8,4],
    'groups': 2,
    'in_c': in_c,
    'image_size': image_size, 
    'num_classes': num_classes,
    'ngpu': ngpu }
  return Net(cfg)

def ShuffleNetG3(in_c=3, image_size=224, num_classes=10, ngpu=1):
  cfg = {
    'out_planes': [240,480,960],
    'num_blocks': [4,8,4],
    'groups': 3,
    'in_c': in_c,
    'image_size': image_size, 
    'num_classes': num_classes,
    'ngpu': ngpu }
  return Net(cfg)


def ShuffleNetG3_x025(in_c=3, image_size=224, num_classes=10, ngpu=1):
  cfg = {
    'out_planes': [60,120,240],
    'num_blocks': [4,8,4],
    'groups': 3,
    'in_c': in_c,
    'image_size': image_size, 
    'num_classes': num_classes,
    'ngpu': ngpu }
  return Net(cfg)
