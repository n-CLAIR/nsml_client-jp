#nsml: floydhub/pytorch:0.3.0-gpu.cuda8cudnn6-py3.17

from distutils.core import setup
setup(
    name='nsml_lstm',
    version='1.0',
    install_requires=[
    ]
)