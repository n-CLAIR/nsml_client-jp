#nsml: nakosung/pytorch:latest-gpu-py3
from distutils.core import setup
setup(
    name='nsml_vae_gan',
    version='1.0',
    install_requires=[
        'visdom',
        'pillow'
    ]
)