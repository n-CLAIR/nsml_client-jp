import torch
from models.DTCWT import *
import models.LiteNetV2 as lnetv2
import models.LiteNet as lnet
import models.DenseNet as dnet
import models.MobileNet as mnet
import models.ShuffleNet as shnet
# import models.DeXpression as dxnet
import torch.optim as optim
from misc.misc import *

import argparse
import time

torch.backends.cudnn.benchmark = True
torch.backends.cudnn.fastest = True


def train(train_loader, model, criterion, optimizer, epoch, global_iter, display=100):
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()

    model.train()

    end = time.time()
    for i, (input, target) in enumerate(train_loader, 0):
        data_time.update(time.time() - end)

        target = torch.LongTensor(target.size(0)).copy_(target).cuda(async=True)
        target_var = torch.autograd.Variable(target)

        input_var = torch.autograd.Variable(input.cuda(async=True))

        # import pdb; pdb.set_trace()
        logit = model(input_var)
        loss = criterion(logit, target_var)

        prec1, prec5, _, _ = accuracy(logit.data, target, topk=(1, 5))
        losses.update(loss.data[0], input.size(0))
        top1.update(prec1[0], input.size(0))
        top5.update(prec5[0], input.size(0))

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        global_iter += 1

        batch_time.update(time.time() - end)
        end = time.time()

        current_lr = optimizer.param_groups[0]['lr']
        if i % display == 0:
            print('Epoch: [{0}][{1}/{2}] [{3}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data {data_time.val:.3f} ({data_time.avg:.3f})\t'
                  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
                  'Prec@1 {top1.val:.3f} ({top1.avg:.3f})\t'
                  'Prec@5 {top5.val:.3f} ({top5.avg:.3f})\t'
                  'lr: {lr:f}'.format(
                epoch, i, len(train_loader), global_iter,
                batch_time=batch_time,
                data_time=data_time,
                loss=losses, top1=top1, top5=top5,
                lr=current_lr))
            sys.stdout.flush()

            trainLogger.write('%d\t%f\t%f\n' % (global_iter, losses.val, top1.val))
            trainLogger.flush()
    return global_iter


def validate(val_loader, model, criterion, epoch, global_iter):
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    incorrect = 0
    test_loss = 0

    model.eval()

    for i, (input, target) in enumerate(val_loader, 1):
        target = torch.LongTensor(target.size(0)).copy_(target).cuda(async=True)
        target_var = torch.autograd.Variable(target, volatile=True)
        input_var = torch.autograd.Variable(input.cuda(async=True), volatile=True)

        logit = model(input_var)
        loss = criterion(logit, target_var)

        test_loss += loss.data[0]
        pred = logit.data.max(1)[1]
        incorrect += pred.ne(target_var.data).cpu().sum()
        prec1, prec5, _, _ = accuracy(logit.data, target, topk=(1, 5))

        losses.update(loss.data[0], input.size(0))
        top1.update(prec1[0], input.size(0))
        top5.update(prec5[0], input.size(0))

    test_loss /= len(val_loader)
    nTotal = len(val_loader.dataset)
    err = 100. * incorrect / nTotal

    print('Test: [{0}/{1}]\t'
          'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
          'Prec@1 {top1.val:.3f} ({top1.avg:.3f})\t'
          'Prec@5 {top5.val:.3f} ({top5.avg:.3f})\t'.format(
        i, len(val_loader),
        loss=losses, top1=top1, top5=top5))
    print('\nTest set: Average loss: {:.4f}, Error: {}/{} ({:.2f}%)\n'.format(
        test_loss, incorrect, nTotal, err))
    sys.stdout.flush()

    valLogger.write('%d\t%f\t%f\t%f\n' % (global_iter, losses.avg, top1.avg, err))
    valLogger.flush()

    return top1.avg


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', default='', help='')
    parser.add_argument('--data_format', default='images', help='raw data format in the HDF files [greyscale|images]')
    parser.add_argument('--k_fold', type=int, default=5, help='k-fold C.C.VV')
    parser.add_argument('--k', type=int, default=0, help='k th split for k-fold cv')
    parser.add_argument('--image_size', type=int, default=224, help='')
    parser.add_argument('--original_size', type=int, default=256, help='')
    parser.add_argument('--nclasses', type=int, default=7, help='number of classes')
    parser.add_argument('--litenet', action='store_true', help='whether to use LiteNet or not')
    parser.add_argument('--litenetv2', action='store_true', help='whether to use LiteNetV2 or not')
    parser.add_argument('--use_dtcwt', action='store_true', help='whether to use dtcwt encoder')
    parser.add_argument('--num_passes', type=int, default=0, help='# of levels in dtcwt')
    parser.add_argument('--groups', type=int, default=0, help='# of groups')
    parser.add_argument('--mobilenet', action='store_true', help='whether to use mobilenet or not')
    parser.add_argument('--shufflenetg3_x025', action='store_true', help='whether to use shufflenet-g3 arch. or not')
    parser.add_argument('--densenet', action='store_true', help='whether to use densenet arch. or not')
    parser.add_argument('--channel_size', type=int, default=0, help='size of base channel size for each arch.')
    parser.add_argument('--layer_config', nargs='+', type=int)
    parser.add_argument('--in_c', type=int, default=0, help='number of input channel size, (image=3, dtcwt=18)')
    parser.add_argument('--ngpu', type=int, default=1, help='# of gpu-cards for data-parallel training')
    parser.add_argument('--lr', type=float, default=0.001, help='initial learning rate')
    parser.add_argument('--wd', type=float, default=0, help='weight decay(a.k.a. L2 regularizor)')
    parser.add_argument('--batch_size', type=int, default=64, help='train batch size')
    parser.add_argument('--val_batch_size', type=int, default=1, help='validation batch size')
    parser.add_argument('--niter', type=int, default=160, help='number of epochs to train for')
    parser.add_argument('--exp', default='sample', help='folder to output logs and model checkpoints')
    parser.add_argument('--display', type=int, default=5, help='interval for console display')
    parser.add_argument('--workers', type=int, default=4, help='# of processes for dataloader')
    opt = parser.parse_args()

    assert opt.in_c > 0
    assert opt.channel_size > 0
    assert opt.groups > 0
    if opt.use_dtcwt:
        assert opt.num_passes > 0

    datasetID = opt.dataset.split('/')[-1]
    if datasetID == 'radboud.h5':
        opt.nclasses = 8
    if datasetID == 'radboud.h5' or \
                    opt.dataset.split('/')[-1] == 'cohn_kanade.h5':
        opt.data_format = 'greyscale'
    opt.torch_version = torch.__version__
    print(opt)

    opt.exp = os.path.join(opt.exp, '%d_in_%d_fold' % (opt.k, opt.k_fold))
    create_exp_dir(opt.exp)
    torch.manual_seed(1)

    # import pdb; pdb.set_trace()
    dataset_trn, dataset_val = get_loader(opt.dataset,
                                          original_size=opt.original_size,
                                          image_size=opt.image_size,
                                          batch_size=opt.batch_size,
                                          val_batch_size=opt.val_batch_size,
                                          workers=opt.workers,
                                          k_fold=opt.k_fold, k=opt.k,
                                          data_format=opt.data_format,
                                          use_dtcwt=opt.use_dtcwt, num_passes=opt.num_passes)

    if opt.litenetv2:
        net = lnetv2.Net(in_c=opt.in_c, image_size=opt.image_size,
                         growth_rate=opt.channel_size, num_classes=opt.nclasses,
                         layer_config=opt.layer_config, groups=1,
                         ngpu=opt.ngpu)
    elif opt.litenet:
        net = lnet.Net(in_c=opt.in_c, image_size=opt.image_size,
                       growth_rate=opt.channel_size, num_classes=opt.nclasses,
                       layer_config=opt.layer_config, groups=opt.groups,
                       ngpu=opt.ngpu)
    elif opt.densenet:
        net = dnet.Net(in_c=opt.in_c,
                       growth_rate=4, num_classes=opt.nclasses,
                       layer_config=[2, 2, 2, 2], compression=0.5, groups=opt.groups,
                       ngpu=opt.ngpu)
    elif opt.mobilenet:
        net = mnet.Net(in_c=opt.in_c, image_size=opt.image_size,
                       base=8, num_classes=opt.nclasses,
                       ngpu=opt.ngpu)
    elif opt.shufflenetg3_x025:
        net = shnet.ShuffleNetG3_x025(in_c=opt.in_c, image_size=opt.image_size,
                                      num_classes=opt.nclasses,
                                      ngpu=opt.ngpu)
    else:
        assert 0
    criterion = torch.nn.CrossEntropyLoss()
    print(net)
    print(opt)

    num_params, size_params = check_model_complexity(net)
    print('# of params in Classification model: %d, size of model: %f MB' % \
          (num_params, size_params))

    net.cuda()
    criterion.cuda()

    trainLogger = open('%s/train.log' % opt.exp, 'w')
    valLogger = open('%s/val.log' % opt.exp, 'w')

    optimizer = optim.Adam(net.parameters(), lr=opt.lr, betas=(0.9, 0.999), weight_decay=0)

    best_prec = -1
    best_epoch = -1
    global_iter = 0
    for epoch in range(1, opt.niter + 1):
        global_iter = train(dataset_trn,
                            net, criterion, optimizer,
                            epoch, global_iter, display=opt.display)
        prec = validate(dataset_val,
                        net, criterion,
                        epoch, global_iter)
        if prec > best_prec:
            best_prec = prec
            best_epoch = epoch
            torch.save(net.state_dict(), '%s/net_epoch_%d.pth' % (opt.exp, epoch))

    print('Best accuracy: %f in epoch %d' % (best_prec, best_epoch))
    trainLogger.close()
    valLogger.close()
