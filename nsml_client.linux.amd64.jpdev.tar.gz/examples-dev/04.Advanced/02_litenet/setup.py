#nsml: thechaos16/torchsample:latest

from distutils.core import setup
setup(
    name='nsml_litenet',
    version='1.0',
    install_requires=[
        'dtcwt'
    ]
)