import torch
import torch.nn as nn

def get_num_params(model):
  import numpy as np
  num_params = 0
  for p in model.parameters():
    #print(p.size())
    num_params += np.prod(p.size())
  return num_params

conv = nn.Conv2d(4, 6, kernel_size=3, groups=2, bias=False)
model = nn.Sequential(conv)
print('group 3x3 conv filter shape: 4 x 6 x 3 x 3, group=2')
print('((4/2)*(6/2))*2 * 3 * 3 = 108')
print(get_num_params(model))


conv = nn.Conv2d(4, 6, kernel_size=1, groups=2, bias=False)
model = nn.Sequential(conv)
print('group 1x1 conv filter shape: 4 x 6 x 1 x 1, group=2')
print('((4/2)*(6/2))*2 = 12')
print(get_num_params(model))

conv = nn.Conv2d(4, 4, kernel_size=3, groups=4, bias=False)
model = nn.Sequential(conv)
print('group 3x3 depth-wise conv filter shape: 4 x 4 x 3 x 3, group=1')
print('4 * 3 * 3 = 36')
print(get_num_params(model))
