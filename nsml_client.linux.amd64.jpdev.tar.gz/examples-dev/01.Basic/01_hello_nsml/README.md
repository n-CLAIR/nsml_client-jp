# hello_nsml

## Description

Dummy example to test nsml command 

## How To Run
```bash
# run a session with dataset name hello_nsml
$ nsml run -d hello_nsml
# session name will be displayed
Session KRXXXXX/hello_nsml/X started.

# you can view the outputs of the script using the logs command
$ nsml logs KRXXXXX/hello_nsml/X
```