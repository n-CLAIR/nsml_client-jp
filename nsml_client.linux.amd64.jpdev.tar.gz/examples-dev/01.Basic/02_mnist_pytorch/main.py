""" 02: MNIST PyTorch
=====================================


Implementation of a CNN on PyTorch using the MNIST dataset.

"""

import argparse
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from PIL import Image
from torch.autograd import Variable
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.datasets.mnist import MNIST, read_image_file, read_label_file

import nsml
from nsml import HAS_DATASET, DATASET_PATH


def bind_model(model, optimizer):
    def save(dir_path):
        state = {
            'model': model.state_dict(),
            'optimizer': optimizer.state_dict()
        }
        torch.save(state, os.path.join(dir_path, 'model.pt'))

    def load(dir_path):
        state = torch.load(os.path.join(dir_path, 'model.pt'))
        model.load_state_dict(state['model'])
        if 'optimizer' in state and optimizer:
            optimizer.load_state_dict(state['optimizer'])
            print('optimizer loaded!')
        print('model loaded!')

    def infer(input_data, top_k):
        model.eval()
        # from list to tensor
        image = torch.stack(preprocess(None, input_data))
        image = Variable(image.cuda())
        clean_state, _ = model(image)
        batch_size, all_cls = clean_state.size()
        # prediction format: ([torch.Tensor], [toch.Tensor)
        prediction = F.softmax(clean_state).topk(min(top_k, all_cls))
        # output format
        # [[(key, prob), (key, prob)... ], ...]
        return list(zip(list(prediction[0].data.cpu().squeeze().tolist()),
                        list(prediction[1].data.cpu().squeeze().tolist())))

    nsml.bind(save=save, load=load, infer=infer)


def _normalize_image(image_tensor, label, transform):
    new_tensor = []
    for idx, image in enumerate(image_tensor):
        if torch.is_tensor(image):  # else, image is instance of PIL.Image
            image = Image.fromarray(image.numpy(), mode='L')
        if label is not None:
            new_tensor.append([transform(image), label[idx]])
        else:
            new_tensor.append(transform(image))
    return new_tensor


def preprocess(output_path, data):
    transform = transforms.Compose([transforms.ToTensor(),
                                    transforms.Normalize((0.1307,), (0.3081,))])
    # if-statement for submit/infer
    if output_path:
        data_set = {
            'train': _normalize_image(data['train']['data'], data['train']['label'], transform),
            'test': _normalize_image(data['test']['data'], data['test']['label'], transform)
        }
        with open(output_path[0], 'wb') as file:
            torch.save(data_set, file)
    else:
        data_set = _normalize_image(data, None, transform)
        return data_set


# supported by dataset owner
def data_loader(root_path):
    root_path = os.path.join(root_path, 'train')
    data_dict = {
        'train': {
            'data': read_image_file(os.path.join(root_path, 'train', 'train-images-idx3-ubyte')),
            'label': read_label_file(os.path.join(root_path, 'train', 'train-labels-idx1-ubyte'))
        },
        'test': {
            'data': read_image_file(os.path.join(root_path, 'test', 't10k-images-idx3-ubyte')),
            'label': read_label_file(os.path.join(root_path, 'test', 't10k-labels-idx1-ubyte'))
        }
    }
    return data_dict


# simple CNN
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 10, kernel_size=5)
        self.conv2 = nn.Conv2d(10, 20, kernel_size=5)
        self.conv2_drop = nn.Dropout2d()
        self.fc1 = nn.Linear(320, 50)
        self.fc1_bn = nn.BatchNorm1d(50)
        self.fc2 = nn.Linear(50, 10)
        self.conv2_bn = nn.BatchNorm2d(20)

    def forward(self, x):
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2_drop(self.conv2_bn(self.conv2(x))), 2))
        x = x.view(-1, 320)
        a = x
        x = F.relu(self.fc1_bn(self.fc1(x)))
        b = x
        x = F.dropout(x, training=self.training)
        x = self.fc2(x)
        h = torch.cat((a, b), dim=1)
        return F.log_softmax(x, dim=1), h


def train(epoch, scope):
    model.train()
    full_data_size = len(train_loader.dataset)
    batch_size = full_data_size // args.batch_size
    residual = full_data_size % args.batch_size
    if residual != 0:
        batch_size += 1

    for batch_idx, (data, target) in enumerate(train_loader):
        target_data = target
        if args.cuda:
            data, target = data.cuda(), target.cuda()
        data, target = Variable(data), Variable(target)
        optimizer.zero_grad()
        output, h = model(data)
        loss = F.nll_loss(output, target)

        loss.backward()
        optimizer.step()
        if batch_idx % args.log_interval == 0:
            nsml.report(
                epoch=epoch,
                epoch_total=args.epochs + 1,
                iter=batch_idx,
                iter_total=batch_size,
                train__loss=loss.data.item(),
                step=(epoch - 1) * batch_size + batch_idx,
                scope=dict(scope, **locals())
            )
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx * len(data), len(train_loader.dataset),
                       100. * batch_idx / len(train_loader), loss.data.item()))


def test(scope):
    model.eval()
    test_loss = 0
    correct = 0
    for data, target in test_loader:
        if args.cuda:
            data, target = data.cuda(), target.cuda()

        with torch.no_grad():
            data, target = Variable(data), Variable(target)
            output, _ = model(data)
            test_loss += F.nll_loss(output, target, reduction='sum').data.item()  # sum up batch loss
            pred = output.data.max(1)[1]  # get the index of the max log-probability
            correct += pred.eq(target.data).cpu().sum()

    test_loss /= len(test_loader.dataset)
    accuracy = correct.item() / len(test_loader.dataset)
    print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
        test_loss, correct, len(test_loader.dataset), 100. * accuracy))

    nsml.report(
        summary=True,
        epoch=epoch,
        test__loss=test_loss,
        test__accuracy=accuracy,
        step=epoch
    )


if __name__ == '__main__':
    # Training settings
    parser = argparse.ArgumentParser(description='PyTorch MNIST Example')
    parser.add_argument('--mode', type=str, default='train')
    parser.add_argument('--batch-size', type=int, default=64, metavar='N',
                        help='input batch size for training (default: 64)')
    parser.add_argument('--test-batch-size', type=int, default=1000, metavar='N',
                        help='input batch size for testing (default: 1000)')
    parser.add_argument('--epochs', type=int, default=10, metavar='N',
                        help='number of epochs to train (default: 10)')
    parser.add_argument('--lr', type=float, default=0.01, metavar='LR',
                        help='learning rate (default: 0.01)')
    parser.add_argument('--momentum', type=float, default=0.5, metavar='M',
                        help='SGD momentum (default: 0.5)')
    parser.add_argument('--no-cuda', action='store_true', default=False,
                        help='disables CUDA training')
    parser.add_argument('--seed', type=int, default=1, metavar='S',
                        help='random seed (default: 1)')
    parser.add_argument('--log-interval', type=int, default=10, metavar='N',
                        help='how many batches to wait before logging training status')
    parser.add_argument('--aux', type=float, default=1.0)
    parser.add_argument('--aux-decay', type=float, default=0.5)
    parser.add_argument('--iteration', type=str, default='0')
    parser.add_argument('--multigpu', action='store_true', default=False)
    parser.add_argument('--pause', type=int, default=0)
    args = parser.parse_args()
    args.cuda = not args.no_cuda and torch.cuda.is_available()

    torch.manual_seed(args.seed)
    if args.cuda:
        torch.cuda.manual_seed(args.seed)

    kwargs = {'num_workers': 1, 'pin_memory': True} if args.cuda else {}
    model = Net()
    if args.multigpu:
        model = nn.DataParallel(model)
    if args.cuda:
        model.cuda()
    optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum)

    bind_model(model, optimizer)
    if args.pause:
        nsml.paused(scope=locals())
    if args.mode == 'train':
        if not HAS_DATASET:
            train_loader = torch.utils.data.DataLoader(
                MNIST('./mnist', train=True, download=True,
                      transform=transforms.Compose([
                          transforms.ToTensor(),
                          transforms.Normalize((0.1307,), (0.3081,))
                      ])),
                batch_size=args.batch_size, shuffle=True, **kwargs)
            test_loader = torch.utils.data.DataLoader(
                MNIST('./mnist', train=False, transform=transforms.Compose([
                    transforms.ToTensor(),
                    transforms.Normalize((0.1307,), (0.3081,))
                ])),
                batch_size=args.batch_size, shuffle=False, **kwargs)
        else:
            preprocessed_file = ['./processed.pt']
            preprocess(preprocessed_file, data_loader(DATASET_PATH))

            dataset = torch.load(preprocessed_file[0])
            train_loader = torch.utils.data.DataLoader(
                dataset['train'], batch_size=args.batch_size, shuffle=True, **kwargs)
            test_loader = torch.utils.data.DataLoader(
                dataset['test'], batch_size=args.batch_size, shuffle=False, **kwargs)

        for epoch in range(1, args.epochs + 1):
            train(epoch, scope=locals())
            test(scope=locals())
            if epoch % 10 == 9:
                nsml.save(epoch)
