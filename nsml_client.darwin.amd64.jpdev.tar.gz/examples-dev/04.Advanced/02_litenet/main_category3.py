import torch
from models.DTCWT import *
import models.LiteNetV2 as lnetv2
import models.LiteNet as lnet
import models.DenseNet as dnet
import models.MobileNet as mnet
import models.ShuffleNet as shnet
import models.SqueezeNet as sqnet
import torch.optim as optim
from misc.misc import *

import argparse
import time

torch.backends.cudnn.benchmark = True
torch.backends.cudnn.fastest = True


def train(train_loader, model, criterion, optimizer, epoch, global_iter, display=100):
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()

    model.train()

    end = time.time()
    for i, (input, target) in enumerate(train_loader, 0):
        data_time.update(time.time() - end)

        target = torch.LongTensor(target.size(0)).copy_(target).cuda(async=True)
        target_var = torch.autograd.Variable(target)

        input_var = torch.autograd.Variable(input.cuda(async=True))

        # import pdb; pdb.set_trace()
        logit = model(input_var)
        loss = criterion(logit, target_var)

        prec1, prec5, _, _ = accuracy(logit.data, target, topk=(1, 5))
        losses.update(loss.data[0], input.size(0))
        top1.update(prec1[0], input.size(0))
        top5.update(prec5[0], input.size(0))

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        global_iter += 1

        batch_time.update(time.time() - end)
        end = time.time()

        current_lr = optimizer.param_groups[0]['lr']
        if i % display == 0:
            print('Epoch: [{0}][{1}/{2}] [{3}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data {data_time.val:.3f} ({data_time.avg:.3f})\t'
                  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
                  'Prec@1 {top1.val:.3f} ({top1.avg:.3f})\t'
                  'Prec@5 {top5.val:.3f} ({top5.avg:.3f})\t'
                  'lr: {lr:f}'.format(
                epoch, i, len(train_loader), global_iter,
                batch_time=batch_time,
                data_time=data_time,
                loss=losses, top1=top1, top5=top5,
                lr=current_lr))
            sys.stdout.flush()

            trainLogger.write('%d\t%f\t%f\n' % (global_iter, losses.val, top1.val))
            trainLogger.flush()
    return global_iter


def validate(val_loader, model, criterion, epoch, global_iter):
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()
    incorrect = 0
    test_loss = 0

    model.eval()

    for i, (input, target) in enumerate(val_loader, 1):
        target = torch.LongTensor(target.size(0)).copy_(target).cuda(async=True)
        target_var = torch.autograd.Variable(target, volatile=True)
        input_var = torch.autograd.Variable(input.cuda(async=True), volatile=True)

        logit = model(input_var)
        loss = criterion(logit, target_var)

        test_loss += loss.data[0]
        pred = logit.data.max(1)[1]
        incorrect += pred.ne(target_var.data).cpu().sum()
        prec1, prec5, _, _ = accuracy(logit.data, target, topk=(1, 5))

        losses.update(loss.data[0], input.size(0))
        top1.update(prec1[0], input.size(0))
        top5.update(prec5[0], input.size(0))

    test_loss /= len(val_loader)
    nTotal = len(val_loader.dataset)
    err = 100. * incorrect / nTotal

    print('Test: [{0}/{1}]\t'
          'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
          'Prec@1 {top1.val:.3f} ({top1.avg:.3f})\t'
          'Prec@5 {top5.val:.3f} ({top5.avg:.3f})\t'.format(
        i, len(val_loader),
        loss=losses, top1=top1, top5=top5))
    print('\nTest set: Average loss: {:.4f}, Error: {}/{} ({:.2f}%)\n'.format(
        test_loss, incorrect, nTotal, err))
    sys.stdout.flush()

    valLogger.write('%d\t%f\t%f\t%f\n' % (global_iter, losses.avg, top1.avg, err))
    valLogger.flush()

    return top1.avg


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', default='', help='')
    parser.add_argument('--image_size', type=int, default=0, help='')
    parser.add_argument('--original_size', type=int, default=0, help='')
    parser.add_argument('--nclasses', type=int, default=0, help='number of classes')
    parser.add_argument('--litenet', action='store_true', help='whether to use LiteNet or not')
    parser.add_argument('--litenetv2', action='store_true', help='whether to use LiteNetV2 or not')
    parser.add_argument('--groups', type=int, default=0, help='# of groups')
    parser.add_argument('--mobilenet', action='store_true', help='whether to use mobilenet or not')
    parser.add_argument('--shufflenetg3', action='store_true', help='whether to use shufflenet-g3 arch. or not')
    parser.add_argument('--densenet', action='store_true', help='whether to use densenet arch. or not')
    parser.add_argument('--channel_size', type=int, default=0, help='size of base channel size for each arch.')
    parser.add_argument('--layer_config', nargs='+', type=int)
    parser.add_argument('--in_c', type=int, default=3, help='number of input channel size, (image=3, dtcwt=18)')
    parser.add_argument('--ngpu', type=int, default=1, help='# of gpu-cards for data-parallel training')
    parser.add_argument('--lr', type=float, default=0.1, help='initial learning rate')
    parser.add_argument('--wd', type=float, default=1e-4, help='weight decay(a.k.a. L2 regularizor)')
    parser.add_argument('--batch_size', type=int, default=0, help='train batch size')
    parser.add_argument('--val_batch_size', type=int, default=0, help='validation batch size')
    parser.add_argument('--niter', type=int, default=0, help='number of epochs to train for')
    parser.add_argument('--exp', default='sample', help='folder to output logs and model checkpoints')
    parser.add_argument('--display', type=int, default=5, help='interval for console display')
    parser.add_argument('--workers', type=int, default=4, help='# of processes for dataloader')
    opt = parser.parse_args()

    assert opt.original_size > 0
    assert opt.image_size > 0
    assert opt.niter > 0
    assert opt.channel_size > 0
    assert opt.batch_size > 0
    assert opt.val_batch_size > 0
    assert opt.groups > 0

    datasetID = opt.dataset.split('/')[-1]
    if datasetID == 'cifar10':
        opt.nclasses = 10
    if datasetID == 'CLS-LOC':
        opt.nclasses = 1000
    if datasetID == 'svhn':
        opt.nclasses = 10

    opt.torch_version = torch.__version__
    print(opt)

    create_exp_dir(opt.exp)
    torch.manual_seed(1)

    # import pdb; pdb.set_trace()
    if datasetID == 'cifar10':
        dataset_trn = get_cifar_loader(opt.dataset, split='train',
                                       batch_size=opt.batch_size,
                                       workers=opt.workers)
        dataset_val = get_cifar_loader(opt.dataset, split='val',
                                       batch_size=opt.val_batch_size,
                                       workers=opt.workers)
    elif datasetID == 'svhn':
        dataset_trn = get_svhn_loader(opt.dataset, split='train',
                                      batch_size=opt.batch_size,
                                      workers=opt.workers)
        dataset_val = get_svhn_loader(opt.dataset, split='test',
                                      batch_size=opt.val_batch_size,
                                      workers=opt.workers)
    elif datasetID == 'CLS-LOC':
        dataset_trn = get_imagenet_loader(os.path.join(opt.dataset, 'train'),
                                          batch_size=opt.batch_size,
                                          workers=opt.workers,
                                          split='train')
        dataset_val = get_imagenet_loader(os.path.join(opt.dataset, 'val'),
                                          batch_size=opt.batch_size,
                                          workers=opt.workers,
                                          split='val')
    else:
        assert 0

    if opt.litenetv2:
        net = lnetv2.Net(in_c=opt.in_c, image_size=opt.image_size,
                         growth_rate=opt.channel_size, num_classes=opt.nclasses,
                         layer_config=opt.layer_config, groups=1,
                         ngpu=opt.ngpu)
    elif opt.litenet:
        net = lnet.Net(in_c=opt.in_c, image_size=opt.image_size,
                       growth_rate=opt.channel_size, num_classes=opt.nclasses,
                       layer_config=opt.layer_config, groups=opt.groups,
                       ngpu=opt.ngpu)
    elif opt.densenet:
        net = dnet.Net(in_c=opt.in_c,
                       growth_rate=opt.channel_size, num_classes=opt.nclasses,
                       layer_config=opt.layer_config, compression=0.5, groups=opt.groups,
                       ngpu=opt.ngpu)
    elif opt.mobilenet:
        net = mnet.Net(in_c=opt.in_c, image_size=opt.image_size,
                       base=opt.channel_size, num_classes=opt.nclasses,
                       ngpu=opt.ngpu)
    elif opt.shufflenetg3:
        net = shnet.ShuffleNetG3(in_c=opt.in_c, image_size=opt.image_size,
                                 num_classes=opt.nclasses,
                                 ngpu=opt.ngpu)
    else:
        assert 0
    criterion = torch.nn.CrossEntropyLoss()
    print(net)
    print(opt)

    num_params, size_params = check_model_complexity(net)
    print('# of params in Classification model: %d, size of model: %f MB' % \
          (num_params, size_params))

    net.cuda()
    criterion.cuda()

    trainLogger = open('%s/train.log' % opt.exp, 'w')
    valLogger = open('%s/val.log' % opt.exp, 'w')

    optimizer = optim.SGD(net.parameters(), lr=opt.lr, momentum=0.9, weight_decay=opt.wd)

    best_prec = -1
    best_epoch = -1
    global_iter = 0
    for epoch in range(1, opt.niter + 1):
        # adjust learning rate for each dataset
        if datasetID == 'cifar10':
            cifar_adjust_lr(optimizer, epoch)
        if datasetID == 'CLS-LOC':
            imagenet_adjust_lr(optimizer, epoch)
        if datasetID == 'svhn':
            svhn_adjust_lr(optimizer, epoch)

        global_iter = train(dataset_trn,
                            net, criterion, optimizer,
                            epoch, global_iter, display=opt.display)
        prec = validate(dataset_val,
                        net, criterion,
                        epoch, global_iter)
        if prec > best_prec:
            best_prec = prec
            best_epoch = epoch
            torch.save(net.state_dict(), '%s/net_epoch_%d.pth' % (opt.exp, epoch))

print('Best accuracy: %f in epoch %d' % (best_prec, best_epoch))
trainLogger.close()
valLogger.close()
