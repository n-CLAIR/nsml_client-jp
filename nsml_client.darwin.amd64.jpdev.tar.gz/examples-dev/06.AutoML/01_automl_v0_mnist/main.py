import argparse
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from PIL import Image
from torch.autograd import Variable
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.datasets.mnist import MNIST, read_image_file, read_label_file

import nsml
from nsml import HAS_DATASET, DATASET_PATH, GPU_NUM
GPU_NUM = int(GPU_NUM)


def _normalize_image(image_tensor, label, transform):
    new_tensor = []
    for idx, image in enumerate(image_tensor):
        if torch.is_tensor(image):  # else, image is instance of PIL.Image
            image = Image.fromarray(image.numpy(), mode='L')
        if label is not None:
            new_tensor.append([transform(image), label[idx]])
        else:
            new_tensor.append(transform(image))
    return new_tensor


def preprocess(output_path, data):
    transform = transforms.Compose([transforms.ToTensor(),
                                    transforms.Normalize((0.1307,), (0.3081,))])
    # if-statement for evalaute/infer
    if output_path:
        data_set = {
            'train': _normalize_image(data['train']['data'], data['train']['label'], transform),
            'test': _normalize_image(data['test']['data'], data['test']['label'], transform)
        }
        with open(output_path[0], 'wb') as file:
            torch.save(data_set, file)
    else:
        data_set = _normalize_image(data['data'], data['label'], transform)
        return data_set


# supported by dataset owner
def data_loader(root_path, train=True):
    if train:
        root_path = os.path.join(root_path, 'train')
        data_dict = {
            'train': {
                'data': read_image_file(os.path.join(root_path, 'train', 'train-images-idx3-ubyte')),
                'label': read_label_file(os.path.join(root_path, 'train', 'train-labels-idx1-ubyte'))
            },
            'test': {
                'data': read_image_file(os.path.join(root_path, 'test', 't10k-images-idx3-ubyte')),
                'label': read_label_file(os.path.join(root_path, 'test', 't10k-labels-idx1-ubyte'))
            }
        }
        return data_dict
    else:
        return read_image_file(os.path.join(root_path, 'test', 'test_data'))


# simple CNN
class Net(nn.Module):
    def __init__(self, depth=1, activation=F.relu, nodes=50):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 10, kernel_size=5)
        self.depth = depth
        self.depth = max(1, self.depth)
        self.activation = activation
        self.nodes = nodes
        self.conv2 = nn.Conv2d(10, 20, kernel_size=5)
        self.conv2_drop = nn.Dropout2d()
        self.conv2_bn = nn.BatchNorm2d(20)
        self.seq = nn.Sequential()
        self._sequential_layers()
        self.fc2 = nn.Linear(self.nodes, 10)

    def _sequential_layers(self):
        for idx in range(self.depth):
            if idx == 0:
                self.seq.add_module('fc_{}'.format(idx+1), nn.Linear(320, self.nodes))
            else:
                self.seq.add_module('fc_{}'.format(idx+1), nn.Linear(self.nodes, self.nodes))
            self.seq.add_module('bn_{}'.format(idx+1), nn.BatchNorm1d(self.nodes))

    def forward(self, x):
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2_drop(self.conv2_bn(self.conv2(x))), 2))
        x = x.view(-1, 320)
        x = self.activation(self.seq(x))
        x = F.dropout(x, training=self.training)
        x = self.fc2(x)
        return F.log_softmax(x)


def train(epoch, scope):
    model.train()
    full_data_size = len(train_loader.dataset)
    batch_size = full_data_size // args.batch_size
    residual = full_data_size % args.batch_size
    if residual != 0:
        batch_size += 1

    grad_of_param = {}
    weight_of_param = {}
    for batch_idx, (data, target) in enumerate(train_loader):
        target_data = target
        if GPU_NUM:
            data, target = data.cuda(), target.cuda()
        data, target = Variable(data, requires_grad=True), Variable(target)
        optimizer.zero_grad()
        output = model(data)
        loss = F.nll_loss(output, target)
        loss.backward()
        optimizer.step()
        # lr_scheduler.step()
        opt_params = optimizer.state_dict()['param_groups'][0]
        step = (epoch - 1) * batch_size + batch_idx + args.iteration
        if args.iteration:
            step += 1
        if step % args.log_interval == 0:
            nsml.report(
                epoch=epoch,
                epoch_total=args.epochs+1,
                iter=batch_idx,
                iter_total=batch_size,
                train__loss=loss.data[0],
                step=step,
                h_param__lr=opt_params['lr'],
                h_param__depth=model.depth,
                h_param__nodes=model.nodes,
                scope=dict(scope, **locals())
            )
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx * len(data), len(train_loader.dataset),
                100. * batch_idx / len(train_loader), loss.data[0]
            ))
    test(scope=scope)


def test(scope):
    model.eval()
    test_loss = 0
    correct = 0
    for data, target in test_loader:
        if GPU_NUM:
            data, target = data.cuda(), target.cuda()
        data, target = Variable(data, volatile=True), Variable(target)
        output = model(data)
        test_loss += F.nll_loss(output, target, size_average=False).data[0]  # sum up batch loss
        pred = output.data.max(1)[1]  # get the index of the max log-probability
        correct += pred.eq(target.data).cpu().sum()

    test_loss /= len(test_loader.dataset)
    accuracy = correct / len(test_loader.dataset)
    print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
        test_loss, correct, len(test_loader.dataset), 100. * accuracy
    ))
    nsml.report(
        summary=True,
        epoch=epoch,
        step=epoch,
        test__loss=test_loss,
        test__accuracy=accuracy
    )
    nsml.save(epoch)


if __name__ == '__main__':
    # Training settings
    parser = argparse.ArgumentParser(description='PyTorch MNIST Example')
    parser.add_argument('--mode', type=str, default='train')
    parser.add_argument('--batch-size', type=int, default=64, metavar='N',
                        help='input batch size for training (default: 64)')
    parser.add_argument('--test-batch-size', type=int, default=1000, metavar='N',
                        help='input batch size for testing (default: 1000)')
    parser.add_argument('--epochs', type=int, default=200, metavar='N',
                        help='number of epochs to train (default: 200)')
    parser.add_argument('--lr', type=float, default=0.01, metavar='LR',
                        help='learning rate (default: 0.01)')
    parser.add_argument('--depth', type=int, default=1)
    parser.add_argument('--size', type=int, default=50)
    parser.add_argument('--activation', type=str, default='relu')
    parser.add_argument('--momentum', type=float, default=0.5, metavar='M',
                        help='SGD momentum (default: 0.5)')
    parser.add_argument('--seed', type=int, default=1, metavar='S',
                        help='random seed (default: 1)')
    parser.add_argument('--log-interval', type=int, default=250, metavar='N',
                        help='how many batches to wait before logging training status')
    parser.add_argument('--iteration', type=int, default=0)
    parser.add_argument('--pause', type=int, default=0)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    if args.activation == 'relu':
        act = F.relu
    elif args.activation == 'sigmoid':
        act = F.sigmoid
    elif args.activation == 'tanh':
        act = F.tanh
    else:
        raise NotImplementedError()
    model = Net(depth=args.depth, nodes=args.size, activation=act)
    kwargs = {}
    if GPU_NUM:
        torch.cuda.manual_seed(args.seed)
        kwargs = {'num_workers': 1, 'pin_memory': True}
        if GPU_NUM > 1:
            model = nn.DataParallel(model)
        model.cuda()

    optimizer = optim.Adam([*model.parameters()], lr=args.lr)

    nsml.bind(model=model, optimizer=optimizer)
    if args.pause:
        nsml.paused(scope=locals())

    if args.mode == 'train':
        if not HAS_DATASET:
            train_loader = torch.utils.data.DataLoader(
                MNIST('/data', train=True, download=True,
                      transform=transforms.Compose([
                          transforms.ToTensor(),
                          transforms.Normalize((0.1307,), (0.3081,))
                      ])),
                batch_size=args.batch_size, shuffle=True, **kwargs
            )
            test_loader = torch.utils.data.DataLoader(
                MNIST('/data', train=False, transform=transforms.Compose([
                    transforms.ToTensor(),
                    transforms.Normalize((0.1307,), (0.3081,))
                ])),
                batch_size=args.batch_size, shuffle=False, **kwargs
            )
        else:
            preprocessed_file = ['./processed.pt']
            nsml.cache(preprocess, output_path=preprocessed_file, data=data_loader(DATASET_PATH))
            dataset = torch.load(preprocessed_file[0])
            train_loader = torch.utils.data.DataLoader(
                dataset['train'], batch_size=args.batch_size, shuffle=True, **kwargs
            )
            test_loader = torch.utils.data.DataLoader(
                dataset['test'], batch_size=args.batch_size, shuffle=False, **kwargs
            )
        for epoch in range(1, args.epochs + 1):
            train(epoch, scope=locals())
